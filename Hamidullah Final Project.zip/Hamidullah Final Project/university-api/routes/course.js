const express = require('express');
const { Course } = require('../models');
const authMiddleware = require('../middlewares/auth');

const router = express.Router();

// Get all courses
router.get('/', authMiddleware, async (req, res) => {
  const courses = await Course.findAll({ where: { deletedAt: null } });
  res.json(courses);
});

// Get a course by ID
router.get('/:id', authMiddleware, async (req, res) => {
  const course = await Course.findByPk(req.params.id);
  if (!course) {
    return res.status(404).json({ message: 'Course not found' });
  }
  res.json(course);
});

// Add a new course (Admin/Teacher only)
router.post('/', authMiddleware, async (req, res) => {
  if (!['admin', 'teacher'].includes(req.user.role)) {
    return res.status(403).json({ message: 'Access denied' });
  }
  const { name, code, description } = req.body;
  const course = await Course.create({ name, code, description });
  res.status(201).json(course);
});

// Update a course
router.put('/:id', authMiddleware, async (req, res) => {
  const { name, code, description } = req.body;
  const course = await Course.findByPk(req.params.id);
  if (!course) {
    return res.status(404).json({ message: 'Course not found' });
  }
  await course.update({ name, code, description });
  res.json(course);
});

// Soft delete a course
router.delete('/:id', authMiddleware, async (req, res) => {
  const course = await Course.findByPk(req.params.id);
  if (!course) {
    return res.status(404).json({ message: 'Course not found' });
  }
  await course.destroy();
  res.json({ message: 'Course deleted' });
});

module.exports = router;
