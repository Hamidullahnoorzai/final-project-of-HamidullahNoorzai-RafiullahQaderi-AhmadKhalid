const express = require('express');
const { User } = require('../models');
const authMiddleware = require('../middlewares/auth');

const router = express.Router();

// Get all users (Admin only)
router.get('/', authMiddleware, async (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Access denied' });
  }
  const users = await User.findAll({ where: { deletedAt: null } });
  res.json(users);
});

// Get a user by ID
router.get('/:id', authMiddleware, async (req, res) => {
  const user = await User.findByPk(req.params.id);
  if (!user) {
    return res.status(404).json({ message: 'User not found' });
  }
  res.json(user);
});

// Update a user (Admin only)
router.put('/:id', authMiddleware, async (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Access denied' });
  }
  const { name, email, role } = req.body;
  const user = await User.findByPk(req.params.id);
  if (!user) {
    return res.status(404).json({ message: 'User not found' });
  }
  await user.update({ name, email, role });
  res.json(user);
});

// Soft delete a user (Admin only)
router.delete('/:id', authMiddleware, async (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Access denied' });
  }
  const user = await User.findByPk(req.params.id);
  if (!user) {
    return res.status(404).json({ message: 'User not found' });
  }
  await user.destroy();
  res.json({ message: 'User deleted' });
});

module.exports = router;
