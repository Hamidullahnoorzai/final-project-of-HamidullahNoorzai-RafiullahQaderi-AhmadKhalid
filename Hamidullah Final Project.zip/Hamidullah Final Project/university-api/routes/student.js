const express = require('express');
const { Student } = require('../models');
const authMiddleware = require('../middlewares/auth');

const router = express.Router();

// Get all students
router.get('/', authMiddleware, async (req, res) => {
  const students = await Student.findAll({ where: { deletedAt: null } });
  res.json(students);
});

// Get a student by ID
router.get('/:id', authMiddleware, async (req, res) => {
  const student = await Student.findByPk(req.params.id);
  if (!student) {
    return res.status(404).json({ message: 'Student not found' });
  }
  res.json(student);
});

// Add a new student
router.post('/', authMiddleware, async (req, res) => {
  const { name, email } = req.body;
  const student = await Student.create({ name, email });
  res.status(201).json(student);
});

// Update a student
router.put('/:id', authMiddleware, async (req, res) => {
  const { name, email } = req.body;
  const student = await Student.findByPk(req.params.id);
  if (!student) {
    return res.status(404).json({ message: 'Student not found' });
  }
  await student.update({ name, email });
  res.json(student);
});

// Soft delete a student
router.delete('/:id', authMiddleware, async (req, res) => {
  const student = await Student.findByPk(req.params.id);
  if (!student) {
    return res.status(404).json({ message: 'Student not found' });
  }
  await student.destroy();
  res.json({ message: 'Student deleted' });
});

module.exports = router;
