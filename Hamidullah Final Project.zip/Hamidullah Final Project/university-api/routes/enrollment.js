const express = require('express');
const { Enrollment, Student, Course } = require('../models');
const authMiddleware = require('../middlewares/auth');

const router = express.Router();

// Get all enrollments
router.get('/', authMiddleware, async (req, res) => {
  const enrollments = await Enrollment.findAll({
    include: [Student, Course],
    where: { deletedAt: null },
  });
  res.json(enrollments);
});

// Enroll a student in a course
router.post('/', authMiddleware, async (req, res) => {
  const { studentId, courseId } = req.body;
  const enrollment = await Enrollment.create({ studentId, courseId });
  res.status(201).json(enrollment);
});

// Remove a student from a course
router.delete('/:id', authMiddleware, async (req, res) => {
  const enrollment = await Enrollment.findByPk(req.params.id);
  if (!enrollment) {
    return res.status(404).json({ message: 'Enrollment not found' });
  }
  await enrollment.destroy();
  res.json({ message: 'Enrollment deleted' });
});

module.exports = router;
