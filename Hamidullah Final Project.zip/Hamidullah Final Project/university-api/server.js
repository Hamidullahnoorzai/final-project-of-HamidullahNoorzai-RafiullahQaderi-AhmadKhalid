const express = require('express');
const bodyParser = require('body-parser');
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/user');
const studentRoutes = require('./routes/student');
const courseRoutes = require('./routes/course');
const enrollmentRoutes = require('./routes/enrollment');

const app = express();
app.use(bodyParser.json());

app.use('/auth', authRoutes);
app.use('/users', userRoutes);
app.use('/students', studentRoutes);
app.use('/courses', courseRoutes);
app.use('/enrollments', enrollmentRoutes);

app.listen(3000, () => console.log('Server running on port 3000'));
